#ifndef __Thal_H
#define __Thal_H


#include "../lib/wiringPi/wiringPi/wiringPi.h"
 

// Mapping table:
/*
	 GPIOn = 6		Pin 31   						Red LED "C"
	 GPIOn = 0		Pin 27  							Green LED "C"
	 GPIOn = 27		Pin 13							Pushbutton "C"
	 GPIOn = 17		Pin 11							Red LED "B"
	 GPIOn = 4	 	Pin 7							Green LED "B"
	 GPIOn = 12		Pin 32							Red LED "A"
	 GPIOn = 1		Pin 28							Green LED "A"
	 GPIOn = 25 		Pin 22  	 						Pushbutton "A"
	 GPIOn = 24 		Pin 18  	 						Pushbutton "B" 
*/



#define RED_LED_A  			12
#define GREEN_LED_A  		1
#define RED_LED_B  			17
#define GREEN_LED_B  		4
#define RED_LED_C 			6
#define GREEN_LED_C 		0

#define PUSHBUTTON_A 		25
#define PUSHBUTTON_B 		24
#define PUSHBUTTON_C 		27

 
 
#define	LOW			 0
#define	HIGH			 1

 
int setupGpio ()
{
	return wiringPiSetupGpio();
}

void _pullUpDnControl     (int pin, int pud)
{
	 pullUpDnControl     ( pin, pud);	
}
  
void _pinMode(int pin, int mode) 
{
	pinMode(pin, mode);
} 

unsigned int  _millis()
{
	 return millis();
}

void _delay(unsigned int howLong)
{
	delay(howLong);
}


void _digitalWrite        (int pin, int value) 
{
	digitalWrite(pin, value);
}
 

int  addGPIOEventListener(int pin, int mode, void (*function)(int Xparam), int Xparam)
{
	return wiringPiISR2( pin,  mode,  function,  Xparam);
}



#endif 
 
 
 
 

 
 
 