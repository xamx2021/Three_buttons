#ifndef __TBUTTON_H
#define __TBUTTON_H

 
#include "halWrp.h"

#include <iostream>
using namespace std;

extern char BTN[3];
extern volatile signed int buttonPressIndex;

class TButton 
{
	char buttonCode;
	public:
	void actualHandler();	
	TButton(int GPIOn, char c);
};
		
	
   TButton * saved_Input_pointer[3];
   int savedInputPointer_index = 0; 
   unsigned long btn_t0;
   
	void BTN_ISR(int pi)		
		{
			unsigned long   t1 = _millis();
			if (t1 - btn_t0 < 200) 	return;
			btn_t0 = t1;
			saved_Input_pointer[pi]->actualHandler();
			_delay (25);	
		} 	
			
	void TButton::actualHandler()
	{
		if( (unsigned int)buttonPressIndex < sizeof(BTN) )BTN[buttonPressIndex] = buttonCode;		
		else cout << "Button buffer is full" << buttonPressIndex <<endl;		
		buttonPressIndex++;			
		cout  << "Button " << buttonCode << " pressed. " <<endl;
	}
	
		
	TButton::TButton(int GPIOn, char c) 
		{ 
			try{
					buttonCode	= c;
					_pinMode(GPIOn, INPUT);
					_pullUpDnControl(GPIOn, PUD_UP);
					if(addGPIOEventListener (GPIOn, INT_EDGE_FALLING, &BTN_ISR, savedInputPointer_index) < 0 ){ cout << "Unable to setup ISR  " << endl;	return;  }				// cout << "Unable to setup ISR:  " << strerror (errno)	<< endl;
					saved_Input_pointer[savedInputPointer_index] = this;
					savedInputPointer_index++;
					cout << "Button '" << buttonCode << "' @ GPIO pin "<< GPIOn << " initialized." << endl;	
				} catch (int e) { cout << "Button '"<< buttonCode << "' failed to initialize." << endl;	}
		}
				

#endif 
 
 

 
 
 