

 This stub version is made to compile without dependencies. Input signals and LEDs are emulated with console I/O.



 	
1.	compile project:
	cd ../../
	make
	
2. launch 3buttons.exe


3. Ctrl + C to terminate






	
	
	