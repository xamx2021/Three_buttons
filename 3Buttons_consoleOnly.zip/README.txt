

 This stub version is made to compile without dependencies. Input signals and LEDs are emulated with console I/O.



 	
1.	compile project:
	cd ../../
	make
	
2. launch 3buttons


3. Ctrl + C to terminate



When started the program generates the following:
  ---------------[ Three buttons guess game ]----------------
  Random sequence generated:    <the sequence, for example A,B,C>
  Player input (A, B or C):

  
You can input keys either one by one followed by enter after each key or as a string terminated by enter key.

The result will be indicated as LEDs: <x> <x> <x>	where "x"  corresponds to LED color: R - red, G - green, O - orange.





	
	
	