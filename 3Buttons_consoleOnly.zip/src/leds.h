#ifndef __TLEDS_H
#define __TLEDS_H


#include "halWrp.h"
 
#include <iostream>
using namespace std;

class TLED
 {
	private:
	int GPIOnR;
	int GPIOnG;
	char ledCode;
 	public:	
	TLED(int R, int G)
		{
			try{
				GPIOnR = R; GPIOnG = G;
				_pinMode(GPIOnR, OUTPUT);
				_pinMode(GPIOnG, OUTPUT);
				} catch (int e) { cout << "LED '"<< ledCode << "' failed to initialize." << endl; }
		}
		
	void setColor(char C)
		{
			switch(C)
			{
				case 'R':	_digitalWrite(GPIOnR, HIGH);	_digitalWrite(GPIOnG, LOW);		break;		  	// Red is On	Green is Off
				case 'G':	_digitalWrite(GPIOnR, LOW);	_digitalWrite(GPIOnG, HIGH);	break;			// Red is Off  Green is On	
				case 'O':	_digitalWrite(GPIOnR, HIGH);	_digitalWrite(GPIOnG, HIGH);	break;			// Red is On  Green is On
				default:		_digitalWrite(GPIOnR, LOW);	_digitalWrite(GPIOnG, LOW);		break;			// Both are Off
			}
		}
 
 };
 

 

#endif 
 