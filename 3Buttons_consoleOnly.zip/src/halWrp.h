#ifndef __Thal_H
#define __Thal_H



#define RED_LED_A  			12
#define GREEN_LED_A  		1
#define RED_LED_B  			17
#define GREEN_LED_B  		4
#define RED_LED_C 			6
#define GREEN_LED_C 		0

#define PUSHBUTTON_A 		25
#define PUSHBUTTON_B 		24
#define PUSHBUTTON_C 		27


#define	LOW			 0
#define	HIGH			 1

 
 
 
#define OUTPUT 0
#define INPUT 0
#define PUD_UP 0
#define INT_EDGE_FALLING 0
 
 
 
 
int setupGpio ()
{
	return 0;
}

void _pullUpDnControl     (int pin, int pud)
{	 
}
  
void _pinMode(int pin, int mode) 
{	
} 

unsigned int  _millis()
{
	 return 0;
}

void _delay(unsigned int howLong)
{
	 
}


void _digitalWrite        (int pin, int value) 
{
	
}
 

int  addGPIOEventListener(int pin, int mode, void (*function)(int Xparam), int Xparam)
{
	return 0;
}



#endif 
 
 
 
 

 
 
 