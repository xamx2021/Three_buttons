

1. compile library:
	cd ./lib/wiringPi
	./build
	
2.	compile project:
	cd ../../
	make
	
3. launch 3buttons.exe
	
	
	