/**
three buttons guess game code
Given a system with the following:

 * LED 1 - which can be {red, green, orange, off}
 * LED 2 - which can be {red, green, orange, off}
 * LED 3 - which can be {red, green, orange, off}
 * Button A
 * Button B
 * Button C

Design & Implement software that fulfills these requirements:

  The system implements a game in which the user has to guess a sequence of three button presses.
  The sequence can contain any combination, e.g. BAC, CCB, AAA.
  The LEDs should always represent the result of the last 3 button presses.
   * LED 3 will always represent the most recent button event
   * LED 2 the one before that
   * LED 1 the one before that

  Red indicates that the button pressed was wrong for this position, and does not appear in a different position.
  Orange indicates that the button pressed was wrong for this position, but it does appear in a different position.
  Green indicates that the button pressed was correct for this position.

  Only "button down" events are generated, so there is no need to deal with held buttons.
  The button sequence is randomly generated on system start-up. 
  After a 3-green result, another random sequence is generated.

  To be written in C++ and executed on Linux.

  The application should be designed to run on the Linux console but with the plan to migrate to some as yet undetermined target hardware.

Provide your test plan and test results as part of your submission.

Test Plan:

		Input-output test:
			1. The software indicates state of readyness at start and when random sequence is generated
			2. Three "button down" event should produce output
	 
**/


#include <iostream>

using namespace std;

char BTN[3];			// Button buffer
volatile signed int buttonPressIndex=0;		//Button index.


#include "halWrp.h"
#include  "buttons.h"
#include  "leds.h"


int main()
{
	if(setupGpio() < 0) { cout << "Unable to setup hardware" << endl; 	return 0;  }			// Setup hardware IO library

	TLED LEDA(RED_LED_A,GREEN_LED_A), LEDB(RED_LED_B,GREEN_LED_B), LEDC(RED_LED_C,GREEN_LED_C);
	TButton b1(PUSHBUTTON_A, 'A'), b2(PUSHBUTTON_B, 'B'),  b3(PUSHBUTTON_C, 'C');	
  
	
	while(1)
	{
		// Initialization test/intro:
		LEDA.setColor('G');	LEDB.setColor('G');	LEDC.setColor('G');
		_delay(400);
		LEDA.setColor('O');	LEDB.setColor('O');	LEDC.setColor('O');
		_delay(400);
		LEDA.setColor('R');	LEDB.setColor('R');	LEDC.setColor('R');
		_delay(400);
		LEDA.setColor(0);	LEDB.setColor(0);	LEDC.setColor(0);
		
		buttonPressIndex=0;
		char LED [] = {'0','0','0'};
		char VAR[] = {'A','B','C'};		// Combinatory
		char RND[3];							
		srand(time(NULL));
		for(int i=0;i<3;i++)RND[i] =  VAR[rand()%3];		// Randomize:	The button sequence is randomly generated on system start-up.
		cout << "  ---------------[ Three buttons guess game ]----------------  " << endl;
		cout << "  Random sequence generated:    " ;	
		for( int i=0;i<3;++i) 	cout << RND[i] << ' ';
		cout << endl;

		do{
				// Input:	& Check:
				cout << "  Player input (A, B or C):" << endl;	
				
				// Button simulator:
				//for( int i=0;i<3;){		cin.get(BTN[i]);			if(BTN[i] == 'A' || BTN[i] == 'B' || BTN[i] == 'C' ) { i++; 	cout << " ok" << endl;} 		}
				
				while(buttonPressIndex<3)  	_delay (100);		
				buttonPressIndex=0;
						 
				// All 3 choices are done, display:    	    
				cout <<  "  Player selected: " ;	
				for(int i=0;i<3;++i) 	cout << BTN[i] << ' ';
				cout << endl;
				
				// Logic:
				for(int i=0;i<3;++i)LED[i]='R';								// Red indicates that the button pressed was wrong for this position, and does not appear in a different position. Default state.

				for(int i=0;i<3;++i)
					{
						if( BTN[i] == RND[i])	LED[i] = 'G';					// Green indicates that the button pressed was correct for this position.
						else
						{
							for(int j=0;j<3;++j)
									if( BTN[i] == RND[j]) LED[i] = 'O';			//  Orange indicates that the button pressed was wrong for this position, but it does appear in a different position.
						}
					}
					
				cout <<  "LEDs: ";	
				for(int i=0;i<3;++i) 	cout << LED[i] << ' ';
				cout << endl;
				LEDA.setColor(LED[0]);		LEDB.setColor(LED[1]);		LEDC.setColor(LED[2]);
		} while( LED[0] != 'G'  || LED[1] != 'G'  || LED[2] != 'G' );

		//After a 3-green result, another random sequence is generated.
		cout <<  "  All done, generating new sequence." << endl << endl << endl;
	}
		
  } 
